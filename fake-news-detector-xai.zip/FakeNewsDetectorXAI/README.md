# Fake News Detector XAI: Explainable News Classification Platform

An advanced NLP, Machine Learning, and Explainable AI (XAI) research portal engineered to classify news as **FAKE** or **REAL** and provide game-theoretic feature attribution insights utilizing **SHAP (SHapley Additive exPlanations)** formulas.

This repository features the dual implementation of a full-stack production application and a streamlined, modular Python/Streamlit machine learning pipeline. This enables students, journalists, and security researchers to audibly inspect classification logic at a raw text-token level.

---

## 🧬 Core Methodology & Explainable AI (XAI)

Typical news classifiers behave as complex "black boxes," issuing predictions without contextual reasoning. **Fake News Detector XAI** bridges this transparency gap by implementing a custom Linear SHAP (Shapley Additive Explanations) formula directly derived from linear TF-IDF vector margins and ML model weights:

$$\phi_i(x) = w_i \cdot (x_i - \mu_i)$$

Where:
- $\phi_i(x)$ represents the localized SHAP attribution value of word $i$.
- $w_i$ represents the fitted regression coefficient or relative classifier weight for word $i$. Positive values drag the prediction towards **FAKE**, while negative values align with **REAL**.
- $x_i$ represents the local TF-IDF density of the word in the active document.
- $\mu_i$ is the corporate background expectancy rate (baseline expectation).

The application uses these values to generate **interactive waterfall models** and highlight the document's body text directly (Red indicates sensational or high-suspect fake signals; Blue identifies objective, matter-of-fact real signals).

---

## 📂 Project Structure

The project has been planned in a clean, production-ready structure:

```
FakeNewsDetectorXAI/
│
├── app.py              # Front-end interactive Streamlit web dashboard
├── train.py            # Preprocessing, corpus scaling, and pipeline training
├── explain.py          # SHAP attribution engine and Matplotlib visualization layouts
├── requirements.txt    # Declared python dependencies for instant local setup
│
├── data/
│   └── fake_news.csv   # Structured learning corpus with labels (0: REAL, 1: FAKE)
│
├── model/
│   ├── model.pkl       # Serialized Classifier Pickle binary (Logistic Regression / XGBoost)
│   └── vectorizer.pkl  # Serialized Vocabulary Vectorizer Pickle binary (TF-IDF bag of n-grams)
│
└── README.md           # Documentation, architecture, and setup instructions
```

---

## 🏗️ System Architecture Diagram

```
[ INPUT NEWS ARCHIVE ] 
        │
        ▼ (train.py)
[ RegEx Parser / Clean Text ]  ──► (LowerCase, Unicode Strip)
        │
        ▼
[ Token Vocabulary Vectorizer ] ──► (TF-IDF Bag-of-ngrams [1, 2], Max Features: 5000)
        │
        ▼
[ XGBoost / Logistic Model Fitted ] ──► (Generates model.pkl & vectorizer.pkl)
        │
        ▼ (explain.py)
[ SHAP Feature Attributor ] ──► (Matches word token density * beta coefficients)
        ├──────────────────────────┐
        ▼                          ▼
[ Red/Blue Highlighter Overlay ]  [ Horizontal SHAP Matplotlib Chart ]
        │                          │
        ├──────────────────────────┘
        ▼ (app.py)
[ Premium Streamlit User Interface ]  ◄── (Home Dashboard, CSV Upload, History DB)
```

---

## ⚙️ Local Installation Guide

Get this project running locally on your workstation in under 3 minutes:

### Prerequisite Checklist
- **Python 3.9+** installed on your OS.
- Sound IDE workspace (VS Code, PyCharm).
- terminal console emulator.

### Step-by-Step Terminal Execution

1. **Extract/Navigate to Project Folder**:
   ```bash
   cd FakeNewsDetectorXAI
   ```

2. **Establish and Ignite Virtual Environment**:
   *On macOS / Ubuntu:*
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```
   *On Windows Prompt:*
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

3. **Install Requirements Package**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Train Baseline Models**:
   Run the train pipeline to clean the local corpus and create your serialized models:
   ```bash
   python train.py
   ```
   *(Expected terminal output should display Accuracy, Precision, Recall, F1 scores and the confusion matrix)*

5. **Fire Up Streamlit Dashboard**:
   ```bash
   streamlit run app.py
   ```
   *Streamlit will automatically assign internal ports and open the website in your primary browser tab!*

---

## 📊 Dataset Scaling Instructions

By default, the project ships with a curated sample corpus within `data/fake_news.csv` to ensure immediate compilation. To scale this system to handle millions of records:

1. **Obtain full corpus**: Download the **Kaggle Fake News Dataset** (or similar datasets containing columns `title`, `text`, and binary `label` - `1` for FAKE, `0` for REAL).
2. **Move files**: Overwrite `data/fake_news.csv` with your downloaded CSV file.
3. **Execute Pipeline**: Terminal execute `python train.py`. The script automatically handles:
   - Dropping missing rows or duplicate articles.
   - Adjusting vocabulary sizing constraints.
   - Stratified dataset partitioning to guarantee testing validation integrity.
