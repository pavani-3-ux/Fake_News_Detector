import os
import re
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix

def clean_text(text):
    if not isinstance(text, str):
        return ""
    # Lowercase
    text = text.lower()
    # Remove HTML tags
    text = re.sub(r'<.*?>', '', text)
    # Remove non-alphanumeric characters but keep basic punctuation for context
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    # Remove extra spaces
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def train_pipeline(data_path="data/fake_news.csv", model_dir="model"):
    print("=" * 60)
    print("      FAKE NEWS DETECTOR XAI: MODEL TRAINING ENGINE")
    print("=" * 60)
    
    # Ensure save directory exists
    os.makedirs(model_dir, exist_ok=True)

    if not os.path.exists(data_path):
        print(f"Error: Data file not found at {data_path}")
        print("Please place your fake_news.csv dataset inside the data/ folder.")
        return False

    print(f"1. Loading dataset from: {data_path}...")
    df = pd.read_csv(data_path)
    
    # Handle missing values
    df = df.dropna(subset=['text', 'label'])
    # Remove duplicates
    initial_len = len(df)
    df = df.drop_duplicates(subset=['text'])
    print(f"   Loaded {initial_len} records. Kept {len(df)} unique records after cleaning.")

    print("2. Preprocessing text headers and bodies...")
    df['cleaned_text'] = df['text'].apply(clean_text)

    # Features and labels
    X = df['cleaned_text']
    y = df['label'].astype(int)

    print("3. Splitting into Train and Test subsets (80% / 20% stratified)...")
    # Using small test_size if dataset is super small to avoid train_test_split empty errors
    test_size = 0.2 if len(X) >= 5 else 0.4
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=y if len(np.unique(y)) > 1 else None
    )

    print(f"   Train samples: {len(X_train)}  | Test samples: {len(X_test)}")

    print("4. Fitting TD-IDF Vectorizer vocabulary...")
    vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2), stop_words='english')
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    print(f"   Vocabulary size: {len(vectorizer.vocabulary_)} features.")

    print("5. Training Classifier model (Logistic Regression preferred for SHAP linearity)...")
    # Using LogisticRegression for absolute compatibility and pristine linear SHAP computations
    model = LogisticRegression(C=1.0, random_state=42, max_iter=1000)
    model.fit(X_train_vec, y_train)

    print("6. Executing Model Evaluation on validation validation dataset...")
    y_pred = model.predict(X_test_vec)

    # Compute metrics
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    cm = confusion_matrix(y_test, y_pred)

    print("\n" + "-"*40)
    print("             MODEL EVALUATION METRICS")
    print("-"*40)
    print(f"Accuracy  : {acc:.4f} ({acc*100:.2f}%)")
    print(f"Precision : {prec:.4f}")
    print(f"Recall    : {rec:.4f}")
    print(f"F1 Score  : {f1:.4f}")
    print("\nConfusion Matrix:")
    print(cm)
    print("-"*40 + "\n")

    # Save model and vectorizer
    model_path = os.path.join(model_dir, "model.pkl")
    vec_path = os.path.join(model_dir, "vectorizer.pkl")

    print(f"7. Persisting binaries to disk...")
    joblib.dump(model, model_path)
    joblib.dump(vectorizer, vec_path)
    print(f"   SUCCESS: Model saved to '{model_path}'")
    print(f"   SUCCESS: Vectorizer saved to '{vec_path}'")
    print("=" * 60)
    return True

if __name__ == "__main__":
    train_pipeline()
