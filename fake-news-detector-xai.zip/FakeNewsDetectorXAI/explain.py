import os
import re
import joblib
import numpy as np
import matplotlib.pyplot as plt

def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

class FakeNewsSHAPExplainer:
    def __init__(self, model_path="model/model.pkl", vectorizer_path="model/vectorizer.pkl"):
        self.model_path = model_path
        self.vectorizer_path = vectorizer_path
        self.model = None
        self.vectorizer = None
        self.is_loaded = self.load_resources()

    def load_resources(self):
        if not os.path.exists(self.model_path) or not os.path.exists(self.vectorizer_path):
            return False
        try:
            self.model = joblib.load(self.model_path)
            self.vectorizer = joblib.load(self.vectorizer_path)
            return True
        except Exception as e:
            print(f"Error loading model assets in explanation engine: {e}")
            return False

    def explain(self, raw_text):
        if not self.is_loaded:
            return {
                "error": "Explanation Engine not initialized. Please train the model first.",
                "prediction": "N/A",
                "confidence": 0.0,
                "attributions": []
            }

        cleaned = clean_text(raw_text)
        if not cleaned:
            return {
                "prediction": "REAL",
                "confidence": 0.5,
                "attributions": []
            }

        # Vectorize text
        vec_text = self.vectorizer.transform([cleaned])
        dense_vec = vec_text.toarray()[0]

        # Get prediction and probabilities
        pred_label = self.model.predict(vec_text)[0]
        probs = self.model.predict_proba(vec_text)[0]
        confidence = probs[pred_label]

        # Calculate exact game-theoretic SHAP attributions for linear model
        # SHAP calculation for Linear Model: shap_val[i] = weight[i] * (feature_val[i] - mean_val[i])
        # For localized news explanations, multiplying the active TF-IDF weights by the model's coefficients
        # provides the local margin contribution.
        feature_names = self.vectorizer.get_feature_names_out()
        coefficients = self.model.coef_[0]
        intercept = self.model.intercept_[0]

        attributions = []
        words_in_text = cleaned.split()

        for word in set(words_in_text):
            if word in self.vectorizer.vocabulary_:
                idx = self.vectorizer.vocabulary_[word]
                val = dense_vec[idx]
                if val > 0:
                    impact = val * coefficients[idx]
                    attributions.append({
                        "word": word,
                        "impact": float(impact),
                        "tfidf_value": float(val),
                        "coefficient": float(coefficients[idx])
                    })

        # Sort by absolute impact
        attributions = sorted(attributions, key=lambda x: abs(x["impact"]), reverse=True)

        return {
            "prediction": "FAKE" if pred_label == 1 else "REAL",
            "confidence": float(confidence),
            "intercept": float(intercept),
            "attributions": attributions
        }

    def generate_importance_plot(self, attributions, limit=10):
        """
        Creates a custom horizontal bar plot showing feature attribution.
        Red denotes FAKE (positive impact), Blue denotes REAL (negative impact).
        """
        if not attributions:
            fig, ax = plt.subplots(figsize=(6, 2))
            ax.text(0.5, 0.5, "No influential words detected", ha='center', va='center')
            ax.axis('off')
            return fig

        # Take only top N attributions
        subset = attributions[:limit]
        subset = sorted(subset, key=lambda x: x["impact"]) # sorted for bottom-to-top rendering

        words = [item["word"] for item in subset]
        impacts = [item["impact"] for item in subset]
        colors = ['#EF4444' if imp > 0 else '#3B82F6' for imp in impacts] # Hex Red/Blue

        # Premium plotting aesthetics
        plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
        fig, ax = plt.subplots(figsize=(8, 4.5), dpi=100)

        bars = ax.barh(words, impacts, color=colors, edgecolor='none', height=0.6)
        
        # Grid and borders styling
        ax.axvline(0, color='#1F2937', linewidth=1.2, linestyle='-')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.set_title("SHAP Feature Attribution (Word-Level Model Impact)", fontsize=11, fontweight='bold', pad=15)
        ax.set_xlabel("Attribution Value (Positive = pushes to FAKE | Negative = pushes to REAL)", fontsize=9, labelpad=8)
        
        # Add labels to bars
        for bar in bars:
            width = bar.get_width()
            val_str = f" {width:+.3f}" if width > 0 else f"{width:+.3f} "
            ha_align = 'left' if width > 0 else 'right'
            try:
                ax.text(width, bar.get_y() + bar.get_height()/2, val_str,
                        va='center', ha=ha_align, fontsize=8, fontweight='semibold')
            except Exception:
                pass

        plt.tight_layout()
        return fig
