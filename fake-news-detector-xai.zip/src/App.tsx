import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldAlert,
  Newspaper,
  FileSpreadsheet,
  TrendingUp,
  Cpu,
  History,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Trash2,
  Search,
  Database,
  UploadCloud,
  Sparkles,
  RefreshCw,
  Sliders,
  Download,
  Info
} from "lucide-react";

// --- Design Theme ---
type TabType = "Home" | "Analysis" | "Batch" | "Analytics" | "Model" | "History";

interface WordAttribution {
  word: string;
  impact: number;
}

interface PredictionRecord {
  id: string;
  title: string;
  snippet: string;
  prediction: "FAKE" | "REAL";
  confidence: number;
  processingTimeMs: number;
  timestamp: string;
  summary: string;
  wordAttributions?: WordAttribution[];
  metrics?: {
    suspiciousnessScore: number;
    biasScore: number;
    sensationalismScore: number;
  };
}

interface StatsData {
  totalPredictions: number;
  fakeNewsDetected: number;
  realNewsDetected: number;
  averageConfidence: number;
  dailyTrends: Array<{ date: string; Fake: number; Real: number; Total: number }>;
  topKeywords: Array<{ word: string; count: number }>;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>("Home");
  const [stats, setStats] = useState<StatsData>({
    totalPredictions: 0,
    fakeNewsDetected: 0,
    realNewsDetected: 0,
    averageConfidence: 0,
    dailyTrends: [],
    topKeywords: []
  });

  const [history, setHistory] = useState<PredictionRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>("");

  // Target Analyzer Inputs
  const [articleTitle, setArticleTitle] = useState<string>("");
  const [articleBody, setArticleBody] = useState<string>("");
  const [activePrediction, setActivePrediction] = useState<PredictionRecord | null>(null);
  const [hoveredWord, setHoveredWord] = useState<{ word: string; impact: number } | null>(null);

  // Batch CSV States
  const [batchRawCsv, setBatchRawCsv] = useState<string>("");
  const [batchResults, setBatchResults] = useState<any[]>([]);
  const [batchProgress, setBatchProgress] = useState<number>(0);
  const [batchMode, setBatchMode] = useState<boolean>(false);

  // Model Train States
  const [modelType, setModelType] = useState<string>("XGBoost Classifier");
  const [cleanTextCheck, setCleanTextCheck] = useState<boolean>(true);
  const [testSplit, setTestSplit] = useState<number>(0.2);
  const [maxFeatures, setMaxFeatures] = useState<number>(5000);
  const [trainMetrics, setTrainMetrics] = useState<any>(null);

  // History Filter
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Fetch telemetry and history logger on start
  const refreshTelemetry = async () => {
    try {
      const statsRes = await fetch("/api/stats");
      const statsJson = await statsRes.json();
      setStats(statsJson);

      const histRes = await fetch("/api/history");
      const histJson = await histRes.json();
      setHistory(histJson);
    } catch (e) {
      console.error("Telemetry Retrieval Failed", e);
    }
  };

  useEffect(() => {
    refreshTelemetry();
  }, [activeTab]);

  // Execute Analysis via server-side Gemini Proxy
  const handleSingleAnalysis = async () => {
    if (!articleBody.trim()) {
      alert("Please enter the main body of your news article to proceed with verification.");
      return;
    }
    setLoading(true);
    setStatusMessage("Classifying article layout & running TF-IDF dictionary lookup...");
    
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: articleTitle, text: articleBody })
      });
      
      const record: PredictionRecord = await res.json();
      setActivePrediction(record);
      refreshTelemetry();
    } catch (e) {
      console.error("Critical Analysis Fault", e);
    } finally {
      setLoading(false);
      setStatusMessage("");
    }
  };

  // Run Batch Processing client-side parser
  const handleRunBatch = async () => {
    if (!batchRawCsv.trim()) {
      alert("Please paste your CSV news logs first.");
      return;
    }
    
    setBatchMode(true);
    setBatchResults([]);
    setBatchProgress(0);

    try {
      // Clean custom row parser
      const lines = batchRawCsv.split("\n").filter(l => l.trim().length > 0);
      if (lines.length < 2) {
        alert("The input matches less than 2 rows (Headers + Article). Make sure it's valid CSV format.");
        setBatchMode(false);
        return;
      }

      // Detect header index
      const headers = lines[0].split(",").map(h => h.trim().toLowerCase());
      const titleIdx = headers.indexOf("title") !== -1 ? headers.indexOf("title") : 0;
      const textIdx = headers.indexOf("text") !== -1 ? headers.indexOf("text") : 1;

      const articlesPayload = [];
      for (let i = 1; i < lines.length; i++) {
        const columns = lines[i].split(",").map(c => c.trim().replace(/^"|"$/g, ""));
        if (columns.length > Math.max(titleIdx, textIdx)) {
          articlesPayload.push({
            title: columns[titleIdx],
            text: columns[textIdx]
          });
        }
      }

      if (articlesPayload.length === 0) {
        alert("Found 0 analyzable rows in your article batch list.");
        setBatchMode(false);
        return;
      }

      // Dispatch payload to Express server
      const res = await fetch("/api/batch-analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ articles: articlesPayload })
      });

      const data = await res.json();
      setBatchResults(data.results || []);
      setBatchProgress(100);
      refreshTelemetry();
    } catch (e) {
      console.error("Batch inference error", e);
      alert("Error processing batch analysis dataset.");
    } finally {
      setBatchMode(false);
    }
  };

  // Run simulated Train call
  const handleModelTrain = async () => {
    setLoading(true);
    setStatusMessage("Preprocessing dataset lines & calculating TF-IDF text vectors...");
    try {
      const res = await fetch("/api/train", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          modelType,
          cleanText: cleanTextCheck,
          testSize: testSplit,
          maxFeatures
        })
      });

      const data = await res.json();
      setTrainMetrics(data);
      refreshTelemetry();
    } catch (e) {
      console.error("Model train terminal failure", e);
    } finally {
      setLoading(false);
      setStatusMessage("");
    }
  };

  // Clear Database History
  const handleWipeHistory = async () => {
    if (confirm("Are you absolutely sure you want to securely wipe the entire prediction history database? This action is irreversible.")) {
      try {
        await fetch("/api/history", { method: "DELETE" });
        refreshTelemetry();
      } catch (e) {
        console.error("Wipe Database Error", e);
      }
    }
  };

  // Dynamic Word Highlighting utility
  const renderHighlightedText = () => {
    if (!activePrediction || !articleBody) return null;
    const attributions = activePrediction.wordAttributions || [];
    
    // Map words to impacts for quick lookup
    const wordWeights: Record<string, number> = {};
    attributions.forEach(item => {
      wordWeights[item.word.toLowerCase()] = item.impact;
    });

    const originalTokens = articleBody.split(/\s+/);
    
    return (
      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-6 leading-relaxed text-slate-200 text-sm md:text-base font-normal shadow-inner max-h-[350px] overflow-y-auto">
        {originalTokens.map((token, i) => {
          // Strip punctuation for lookup but retain original to preserve document layout
          const cleanToken = token.toLowerCase().replace(/[^a-z]/g, "");
          const weight = wordWeights[cleanToken];

          if (weight !== undefined) {
            const isFakePush = weight > 0.01;
            const isRealPush = weight < -0.01;

            if (isFakePush) {
              return (
                <span
                  key={i}
                  id={`word-fake-${i}`}
                  onMouseEnter={() => setHoveredWord({ word: token, impact: weight })}
                  onMouseLeave={() => setHoveredWord(null)}
                  className="mx-1 px-1.5 py-0.5 rounded border bg-rose-500/15 border-rose-500/30 text-rose-400 font-semibold cursor-help transition-all duration-150 hover:bg-rose-500/25"
                >
                  {token}
                </span>
              );
            } else if (isRealPush) {
              return (
                <span
                  key={i}
                  id={`word-real-${i}`}
                  onMouseEnter={() => setHoveredWord({ word: token, impact: weight })}
                  onMouseLeave={() => setHoveredWord(null)}
                  className="mx-1 px-1.5 py-0.5 rounded border bg-blue-500/15 border-blue-500/30 text-blue-400 font-semibold cursor-help transition-all duration-150 hover:bg-blue-500/25"
                >
                  {token}
                </span>
              );
            }
          }

          return <span key={i} className="mx-0.5">{token}</span>;
        })}
      </div>
    );
  };

  // Filter dynamic history
  const filteredHistory = history.filter(item => {
    const s = searchQuery.toLowerCase();
    return (
      item.title.toLowerCase().includes(s) ||
      item.snippet.toLowerCase().includes(s) ||
      item.prediction.toLowerCase().includes(s)
    );
  });

  return (
    <div id="main-root" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-500/30 selection:text-blue-200">
      
      {/* --- App Header Banner --- */}
      <header id="app-header" className="bg-slate-900 border-b border-slate-800 py-4 px-6 md:px-12 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-md shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-tr from-rose-500 to-blue-600 rounded-xl shadow-lg relative overflow-hidden group">
            <ShieldAlert className="w-6 h-6 text-white relative z-10" />
            <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <div>
            <h1 className="text-xl font-bold font-display tracking-tight text-white flex items-center gap-2">
              Fake News Detector <span className="text-sm bg-gradient-to-r from-rose-500 to-blue-500 bg-clip-text text-transparent font-black px-1.5 py-0.5 border border-rose-500/30 rounded-md font-mono">XAI v1.2</span>
            </h1>
            <p className="text-xs text-slate-400">Explainable NLP Fact-Checking & Feature Attribution Suite</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-mono text-slate-300">Local DB Status: Synced</span>
          </div>
          <button 
            id="refresh-telemetry-btn"
            onClick={refreshTelemetry} 
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg border border-transparent hover:border-slate-700 transition"
            title="Refresh statistics"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* --- Main Contents Context Frame --- */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        
        {/* Sidebar Nav */}
        <nav id="app-sidebar" className="w-full md:w-64 bg-slate-900/60 border-b md:border-b-0 md:border-r border-slate-800 p-4 flex md:flex-col gap-1.5 overflow-x-auto md:overflow-y-auto md:shrink-0">
          <p className="hidden md:block text-[10px] font-bold text-slate-500 uppercase tracking-widest px-3 mb-2">Research Portal</p>
          
          <button
            id="nav-home"
            onClick={() => setActiveTab("Home")}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition duration-200 ${
              activeTab === "Home" 
                ? "bg-blue-600/15 border border-blue-500/30 text-blue-400" 
                : "border border-transparent text-slate-400 hover:text-slate-100 hover:bg-slate-800/50"
            }`}
          >
            <Database className="w-4 h-4 shrink-0" />
            <span className="truncate">Home Dashboard</span>
          </button>

          <button
            id="nav-analysis"
            onClick={() => setActiveTab("Analysis")}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition duration-200 ${
              activeTab === "Analysis" 
                ? "bg-blue-600/15 border border-blue-500/30 text-blue-400" 
                : "border border-transparent text-slate-400 hover:text-slate-100 hover:bg-slate-800/50"
            }`}
          >
            <Newspaper className="w-4 h-4 shrink-0" />
            <span className="truncate">News Analyzer</span>
          </button>

          <button
            id="nav-batch"
            onClick={() => setActiveTab("Batch")}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition duration-200 ${
              activeTab === "Batch" 
                ? "bg-blue-600/15 border border-blue-500/30 text-blue-400" 
                : "border border-transparent text-slate-400 hover:text-slate-100 hover:bg-slate-800/50"
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 shrink-0" />
            <span className="truncate">Batch CSV</span>
          </button>

          <button
            id="nav-analytics"
            onClick={() => setActiveTab("Analytics")}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition duration-200 ${
              activeTab === "Analytics" 
                ? "bg-blue-600/15 border border-blue-500/30 text-blue-400" 
                : "border border-transparent text-slate-400 hover:text-slate-100 hover:bg-slate-800/50"
            }`}
          >
            <TrendingUp className="w-4 h-4 shrink-0" />
            <span className="truncate">Analytics Suite</span>
          </button>

          <button
            id="nav-model"
            onClick={() => setActiveTab("Model")}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition duration-200 ${
              activeTab === "Model" 
                ? "bg-blue-600/15 border border-blue-500/30 text-blue-400" 
                : "border border-transparent text-slate-400 hover:text-slate-100 hover:bg-slate-800/50"
            }`}
          >
            <Cpu className="w-4 h-4 shrink-0" />
            <span className="truncate">Model Studio</span>
          </button>

          <button
            id="nav-history"
            onClick={() => setActiveTab("History")}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition duration-200 ${
              activeTab === "History" 
                ? "bg-blue-600/15 border border-blue-500/30 text-blue-400" 
                : "border border-transparent text-slate-400 hover:text-slate-100 hover:bg-slate-800/50"
            }`}
          >
            <History className="w-4 h-4 shrink-0" />
            <span className="truncate">Audit Logs</span>
          </button>
        </nav>

        {/* --- Main View Stage -- */}
        <main id="app-stage" className="flex-1 overflow-y-auto p-6 md:p-10 select-text">
          <AnimatePresence mode="wait">
            
            {/* 1. HOME DASHBOARD */}
            {activeTab === "Home" && (
              <motion.div
                key="home"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div>
                  <h2 className="text-2xl font-bold font-display text-white">NLP Research Hub & Statistics</h2>
                  <p className="text-sm text-slate-400">Overview of verification telemetry and structural metadata metrics.</p>
                </div>

                {/* Metrics row */}
                <div id="metrics-summary-grid" className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md hover:border-slate-700 transition">
                    <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Audited</p>
                    <p className="text-3xl font-bold font-display text-slate-100 mt-2">{stats.totalPredictions}</p>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full mt-4 overflow-hidden">
                      <div className="bg-slate-400 h-full rounded-full" style={{ width: "100%" }} />
                    </div>
                  </div>

                  <div className="bg-slate-900 border border-rose-950/40 rounded-2xl p-6 shadow-md hover:border-rose-900/50 transition">
                    <p className="text-xs font-semibold text-rose-400 uppercase tracking-wider">Fake Flagged</p>
                    <p className="text-3xl font-bold font-display text-rose-500 mt-2">{stats.fakeNewsDetected}</p>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full mt-4 overflow-hidden">
                      <div 
                        className="bg-rose-500 h-full rounded-full transition-all duration-500" 
                        style={{ width: `${stats.totalPredictions > 0 ? (stats.fakeNewsDetected / stats.totalPredictions) * 100 : 0}%` }} 
                      />
                    </div>
                  </div>

                  <div className="bg-slate-900 border border-emerald-950/40 rounded-2xl p-6 shadow-md hover:border-emerald-900/50 transition">
                    <p className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">Real Confirmed</p>
                    <p className="text-3xl font-bold font-display text-emerald-500 mt-2">{stats.realNewsDetected}</p>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full mt-4 overflow-hidden">
                      <div 
                        className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                        style={{ width: `${stats.totalPredictions > 0 ? (stats.realNewsDetected / stats.totalPredictions) * 100 : 0}%` }} 
                      />
                    </div>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md hover:border-slate-700 transition">
                    <p className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Avg Confidence</p>
                    <p className="text-3xl font-bold font-display text-blue-400 mt-2">{stats.averageConfidence}%</p>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full mt-4 overflow-hidden">
                      <div 
                        className="bg-blue-400 h-full rounded-full transition-all duration-500" 
                        style={{ width: `${stats.averageConfidence}%` }} 
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 md:gap-8">
                  <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6">
                    <div className="flex items-center gap-3">
                      <Sparkles className="w-5 h-5 text-yellow-400" />
                      <h3 className="text-lg font-bold font-display text-white">Game-Theoretic SHAP Attributions</h3>
                    </div>

                    <p className="text-sm text-slate-300 leading-relaxed">
                      This system measures and visualizes vocabulary impact using Local Explainable AI models. For every predicted article, individual words are evaluated on a coordinate line based on how heavily they steer the prediction.
                    </p>

                    <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 font-mono text-xs text-slate-300 space-y-2">
                      <p className="font-semibold text-slate-400">// Visualizing SHAP attributions logic</p>
                      <div className="flex items-center justify-between border-b border-slate-900 pb-2">
                        <span>Clickbait Buzzwords (e.g., "miracle juice")</span>
                        <span className="text-rose-500 font-bold">+0.58 (Steers to FAKE)</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Neutral Nouns (e.g., "NASA research")</span>
                        <span className="text-blue-500 font-bold">-0.35 (Steers to REAL)</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <button 
                        id="hero-verify-btn"
                        onClick={() => setActiveTab("Analysis")} 
                        className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold py-2 px-4 rounded-lg shadow transition"
                      >
                        Launch Real-time Analyzer
                      </button>
                      <button 
                        id="hero-train-btn"
                        onClick={() => setActiveTab("Model")} 
                        className="text-slate-400 hover:text-white text-xs font-semibold py-2 px-3 transition"
                      >
                        Inspect ML Pipelines →
                      </button>
                    </div>
                  </div>

                  <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                    <h3 className="text-sm font-semibold font-display text-slate-300 uppercase tracking-wider">Top Suspicious Keywords</h3>
                    <div className="space-y-3">
                      {stats.topKeywords && stats.topKeywords.length > 0 ? (
                        stats.topKeywords.map((kw, i) => (
                          <div key={i} className="flex items-center justify-between text-xs bg-slate-950/50 border border-slate-800/80 rounded-xl px-4 py-2.5">
                            <span className="font-mono text-slate-400 font-medium">"{kw.word}"</span>
                            <div className="flex items-center gap-3">
                              <span className="text-[10px] text-rose-500 bg-rose-500/10 px-2 py-0.5 rounded-full font-semibold">FAKE drag</span>
                              <span className="text-slate-300 font-mono font-bold">hits: {kw.count}</span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-slate-500">No telemetry keywords matching. Verify news documents to collect terms.</p>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* 2. NEWS ANALYZER */}
            {activeTab === "Analysis" && (
              <motion.div
                key="analysis"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div>
                  <h2 className="text-2xl font-bold font-display text-white">Interactive News Verification</h2>
                  <p className="text-sm text-slate-400">Classify individual news headlines and retrieve word-level SHAP explanation overlays.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
                  
                  {/* Left Column Input */}
                  <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-5">
                    <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
                      <Sliders className="w-4 h-4 text-blue-500" /> Article Verification Inputs
                    </h3>
                    
                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-400">Headline/Title (Optional)</label>
                      <input 
                        id="title-input"
                        type="text" 
                        value={articleTitle}
                        onChange={(e) => setArticleTitle(e.target.value)}
                        placeholder="e.g., Instant Breakthrough Elixir Cures Aging Globally"
                        className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm rounded-xl px-4 py-3 text-slate-200 outline-none transition"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-400">Article Body Content</label>
                      <textarea 
                        id="body-input"
                        rows={10}
                        value={articleBody}
                        onChange={(e) => setArticleBody(e.target.value)}
                        placeholder="Copy paste raw paragraphs here to run explainable pipeline classification..."
                        className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm rounded-xl px-4 py-3 text-slate-300 outline-none transition resize-none leading-relaxed"
                      />
                    </div>

                    <button
                      id="submit-analysis-btn"
                      onClick={handleSingleAnalysis}
                      disabled={loading}
                      className="w-full bg-gradient-to-r from-blue-600 to-rose-600 hover:from-blue-700 hover:to-rose-700 disabled:from-slate-700 disabled:to-slate-700 text-white font-semibold py-3 px-4 rounded-xl text-sm transition shadow-lg flex items-center justify-center gap-2"
                    >
                      {loading ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Auditing Draft...</span>
                        </>
                      ) : (
                        <>
                          <ShieldAlert className="w-4 h-4" />
                          <span>Run Audit pipeline</span>
                        </>
                      )}
                    </button>

                    {loading && (
                      <div className="text-center py-2 space-y-1.5">
                        <p className="text-xs text-blue-400 animate-pulse font-medium">{statusMessage}</p>
                      </div>
                    )}
                  </div>

                  {/* Right Column Results */}
                  <div className="lg:col-span-3 space-y-6">
                    {activePrediction ? (
                      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6">
                        
                        {/* Title Results Header */}
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
                          <div>
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">Classification Result</span>
                            <div className="flex items-center gap-2 mt-1">
                              {activePrediction.prediction === "FAKE" ? (
                                <span className="bg-rose-500/10 border border-rose-500/20 text-rose-500 font-extrabold text-lg px-3 py-1 rounded-lg tracking-tight">⛔ FAKE NEWS FLAGGED</span>
                              ) : (
                                <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 font-extrabold text-lg px-3 py-1 rounded-lg tracking-tight">🪐 REAL VERIFIED</span>
                              )}
                            </div>
                          </div>

                          <div className="text-left md:text-right">
                            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-mono">Confidence rating</span>
                            <p className="text-2xl font-bold font-display text-white mt-1">
                              {Math.round(activePrediction.confidence * 100)}%
                            </p>
                          </div>
                        </div>

                        {/* Summary */}
                        <div className="space-y-2">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">Core Pipeline Summary</h4>
                          <p className="text-sm text-slate-300 leading-relaxed bg-slate-950/40 p-4 border border-slate-800/80 rounded-xl">
                            {activePrediction.summary}
                          </p>
                        </div>

                        {/* Highlighter Stage */}
                        <div className="space-y-2">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">Feature-Highlighted Article Content</h4>
                          {renderHighlightedText()}
                          
                          {/* Hover Word Detail Card */}
                          <div className="h-10 pt-1.5">
                            {hoveredWord ? (
                              <p className="text-xs text-slate-300 flex items-center gap-2">
                                <Info className="w-3.5 h-3.5 text-blue-400" />
                                Focused token: <span className="font-mono font-bold text-white">"{hoveredWord.word}"</span> |
                                local model impact value: 
                                <span className={`font-mono font-bold ${hoveredWord.impact > 0 ? "text-rose-400" : "text-blue-400"}`}>
                                  {hoveredWord.impact > 0 ? `+${hoveredWord.impact.toFixed(4)} (FAKE push)` : `${hoveredWord.impact.toFixed(4)} (REAL push)`}
                                </span>
                              </p>
                            ) : (
                              <p className="text-xs text-slate-500">Hover colored terms above to inspect local game-theoretic coefficient weight parameters.</p>
                            )}
                          </div>
                        </div>

                        {/* Custom Waterfall / Attribution Plot */}
                        {activePrediction.wordAttributions && activePrediction.wordAttributions.length > 0 && (
                          <div className="space-y-4 pt-3">
                            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">SHAP Local Feature Attribution Mapping</h4>
                            
                            {/* SVG Chart */}
                            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs">
                              <p className="text-[10px] text-slate-400 mb-3 text-center">Positive Attributions push to FAKE (Red) | Negative Attributions push to REAL (Blue)</p>
                              <div className="space-y-2.5">
                                {activePrediction.wordAttributions.slice(0, 8).map((attr, idx) => {
                                  const maxVal = 0.6; // Scale boundary
                                  const widthPerc = Math.min((Math.abs(attr.impact) / maxVal) * 50, 50);
                                  const isFake = attr.impact > 0;

                                  return (
                                    <div key={idx} className="grid grid-cols-12 items-center gap-2 font-mono">
                                      <span className="col-span-3 truncate text-right pr-2 text-slate-300">"{attr.word}"</span>
                                      
                                      <div className="col-span-6 h-4 bg-slate-900 rounded-full relative overflow-hidden">
                                        <div 
                                          className={`absolute h-full rounded-full transition-all duration-300 ${isFake ? "bg-rose-500 right-1/2 origin-right" : "bg-blue-500 left-1/2 origin-left"}`}
                                          style={{ 
                                            width: `${widthPerc}%`,
                                            left: isFake ? "auto" : `calc(50% + ${attr.impact * 50 / maxVal}%)`,
                                            right: isFake ? `calc(50% - ${attr.impact * 50 / maxVal}%)` : "auto"
                                          }}
                                        />
                                        <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-slate-700" />
                                      </div>

                                      <span className={`col-span-3 pl-2 text-left font-bold ${isFake ? "text-rose-400" : "text-blue-400"}`}>
                                        {attr.impact > 0 ? `+${attr.impact.toFixed(3)}` : attr.impact.toFixed(3)}
                                      </span>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Telemetry Metrics */}
                        {activePrediction.metrics && (
                          <div className="grid grid-cols-3 gap-4 pt-2">
                            <div className="bg-slate-950/40 border border-slate-850 p-4 rounded-xl text-center">
                              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Suspiciousness</p>
                              <p className="text-xl font-bold font-display text-slate-100 mt-1">{activePrediction.metrics.suspiciousnessScore}%</p>
                            </div>
                            <div className="bg-slate-950/40 border border-slate-850 p-4 rounded-xl text-center">
                              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Sensationalism</p>
                              <p className="text-xl font-bold font-display text-slate-100 mt-1">{activePrediction.metrics.sensationalismScore}%</p>
                            </div>
                            <div className="bg-slate-950/40 border border-slate-850 p-4 rounded-xl text-center">
                              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Bias Marker</p>
                              <p className="text-xl font-bold font-display text-slate-100 mt-1">{activePrediction.metrics.biasScore}%</p>
                            </div>
                          </div>
                        )}
                        
                      </div>
                    ) : (
                      <div className="h-full border border-dashed border-slate-800 rounded-2xl flex flex-col items-center justify-center text-center p-8 text-slate-500 space-y-4 min-h-[400px]">
                        <div className="p-4 bg-slate-900 border border-slate-850 rounded-2xl text-slate-400">
                          <Newspaper className="w-8 h-8" />
                        </div>
                        <div>
                          <p className="font-semibold text-slate-350">Awaiting Verification Target</p>
                          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">Please insert target terms and full sentences in the analyzer screen to initiate deep checking sequence.</p>
                        </div>
                      </div>
                    )}
                  </div>

                </div>
              </motion.div>
            )}

            {/* 3. BATCH CSV */}
            {activeTab === "Batch" && (
              <motion.div
                key="batch"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div>
                  <h2 className="text-2xl font-bold font-display text-white">Batch Analysis</h2>
                  <p className="text-sm text-slate-400">Import structured tables containing hundreds of titles and evaluate them simultaneously.</p>
                </div>

                <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 md:p-8 space-y-6">
                  <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
                    <UploadCloud className="w-5 h-5 text-blue-400" />
                    <div>
                      <h3 className="text-base font-bold text-white">Upload Tabular Dataset</h3>
                      <p className="text-xs text-slate-400">Paste your raw CSV below. Columns MUST contain headers "title" and "text" to process correctly.</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <textarea
                      id="batch-csv-input"
                      rows={8}
                      value={batchRawCsv}
                      onChange={(e) => setBatchRawCsv(e.target.value)}
                      placeholder='title,text&#10;Miracle berry cures aging instantly,A tropical secret is hidden by medical cartels.&#10;Mars rover Perseverance confirmed subsurface water flows,NASA scientific dispatch reports Martian glacier pools.'
                      className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-xs rounded-xl p-4 text-slate-350 outline-none transition font-mono leading-relaxed"
                    />
                  </div>

                  <button
                    id="batch-analyze-btn"
                    onClick={handleRunBatch}
                    disabled={batchMode}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs py-2.5 px-6 rounded-xl transition"
                  >
                    {batchMode ? "Executing Classification Pipeline..." : "Start Batch Analysis"}
                  </button>

                  {batchProgress > 0 && (
                    <div className="space-y-1.5 w-full bg-slate-950 border border-slate-850 p-4 rounded-xl">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-400">Batch ingestion rate</span>
                        <span className="font-bold text-blue-400">{batchProgress}%</span>
                      </div>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div className="bg-blue-500 h-full rounded-full transition-all duration-300" style={{ width: `${batchProgress}%` }} />
                      </div>
                    </div>
                  )}

                  {batchResults.length > 0 && (
                    <div className="space-y-4 pt-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-slate-300 font-display">Processed Records ({batchResults.length})</h4>
                        
                        {/* Download button */}
                        <a
                          id="export-csv-link"
                          href={`data:text/csv;charset=utf-8,${encodeURIComponent(
                            "Title,Predicted Label,Model Confidence\n" + 
                            batchResults.map(r => `"${r.title}","${r.prediction}",${r.confidence}`).join("\n")
                          )}`}
                          download="fake_news_xai_batch_results.csv"
                          className="bg-slate-800 hover:bg-slate-700 text-slate-100 font-semibold text-xs py-2 px-3.5 border border-slate-700 rounded-lg flex items-center gap-2 transition"
                        >
                          <Download className="w-3.5 h-3.5" /> Export results (.csv)
                        </a>
                      </div>

                      <div className="overflow-x-auto border border-slate-800 rounded-xl">
                        <table className="w-full border-collapse text-left text-xs bg-slate-950/40">
                          <thead>
                            <tr className="border-b border-slate-800 bg-slate-900/80 font-bold text-slate-400 font-mono">
                              <th className="px-4 py-3">Headline/Snippet</th>
                              <th className="px-4 py-3 text-center">Prediction</th>
                              <th className="px-4 py-3 text-right">Confidence rating</th>
                            </tr>
                          </thead>
                          <tbody>
                            {batchResults.map((rec, i) => (
                              <tr key={i} className="border-b border-slate-850 hover:bg-slate-900/35 transition">
                                <td className="px-4 py-3.5 font-medium text-slate-200">{rec.title}</td>
                                <td className="px-4 py-3.5 text-center">
                                  <span className={`inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${rec.prediction === "FAKE" ? "bg-rose-500/10 text-rose-500" : "bg-emerald-500/10 text-emerald-500"}`}>
                                    {rec.prediction}
                                  </span>
                                </td>
                                <td className="px-4 py-3.5 text-right font-mono font-semibold text-slate-300">
                                  {Math.round(rec.confidence * 100)}%
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                </div>
              </motion.div>
            )}

            {/* 4. ANALYTICS SUITE */}
            {activeTab === "Analytics" && (
              <motion.div
                key="analytics"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div>
                  <h2 className="text-2xl font-bold font-display text-white">Analytics Suite</h2>
                  <p className="text-sm text-slate-400">Review core models' predictive statistics, historical distributions, and pipeline trends.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  
                  {/* Distribution Card */}
                  <div className="bg-slate-900 border border-slate-850 p-6 md:p-8 rounded-2xl space-y-4">
                    <h3 className="text-sm font-semibold font-display uppercase tracking-widest text-slate-400">Class Label Volumes</h3>
                    
                    {/* SVG Pie Chart simulation */}
                    <div className="flex flex-col items-center justify-center space-y-4 py-6">
                      <svg width="180" height="180" viewBox="0 0 100 100" className="transform -rotate-90">
                        <circle cx="50" cy="50" r="40" fill="none" stroke="#334155" strokeWidth="20" />
                        
                        {/* Slice FAKE (Red) */}
                        <circle 
                          cx="50" 
                          cy="50" 
                          r="40" 
                          fill="none" 
                          stroke="#ef4444" 
                          strokeWidth="20" 
                          strokeDasharray={`${stats.totalPredictions > 0 ? (stats.fakeNewsDetected / stats.totalPredictions) * 251.2 : 125.6} 251.2`} 
                        />
                        {/* Slice REAL (Blue/Green) */}
                        <circle 
                          cx="50" 
                          cy="50" 
                          r="40" 
                          fill="none" 
                          stroke="#10b981" 
                          strokeWidth="20" 
                          strokeDasharray={`${stats.totalPredictions > 0 ? (stats.realNewsDetected / stats.totalPredictions) * 251.2 : 125.6} 251.2`}
                          strokeDashoffset={`-${stats.totalPredictions > 0 ? (stats.fakeNewsDetected / stats.totalPredictions) * 251.2 : 125.6}`}
                        />
                      </svg>
                      
                      <div className="flex items-center gap-6 text-xs text-slate-300">
                        <div className="flex items-center gap-2">
                          <span className="w-3" style={{ height: "12px", borderRadius: "3px", background: "#ef4444" }} />
                          <span>Fake flagged ({stats.fakeNewsDetected})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="w-3" style={{ height: "12px", borderRadius: "3px", background: "#10b981" }} />
                          <span>Real confirmed ({stats.realNewsDetected})</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Trend chart */}
                  <div className="bg-slate-900 border border-slate-850 p-6 md:p-8 rounded-2xl space-y-4">
                    <h3 className="text-sm font-semibold font-display uppercase tracking-widest text-slate-400">Daily Trend Analysis</h3>
                    
                    {/* SVG Line simulation */}
                    <div className="py-6 h-[180px] flex items-end">
                      {stats.dailyTrends && stats.dailyTrends.length > 0 ? (
                        <div className="w-full flex justify-between items-end gap-1 px-2 h-full">
                          {stats.dailyTrends.map((trend, i) => {
                            const maxVal = Math.max(...stats.dailyTrends.map(t => t.Total), 1);
                            const totalHeight = (trend.Total / maxVal) * 120;
                            const fakeHeight = (trend.Fake / maxVal) * 120;

                            return (
                              <div key={i} className="flex-1 flex flex-col items-center gap-1.5 font-mono text-[9px] text-slate-500">
                                <div className="w-5 bg-slate-950 rounded-md border border-slate-850 h-[120px] flex flex-col justify-end overflow-hidden relative">
                                  {/* Fake parts */}
                                  <div className="bg-rose-500 w-full" style={{ height: `${fakeHeight}px` }} />
                                  {/* Real parts remaining */}
                                  <div className="bg-emerald-500 w-full" style={{ height: `${totalHeight - fakeHeight}px` }} />
                                </div>
                                <span className="truncate max-w-full text-slate-400">{trend.date}</span>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <p className="text-xs text-slate-500 text-center w-full">Awaiting daily log metrics.</p>
                      )}
                    </div>
                  </div>

                </div>
              </motion.div>
            )}

            {/* 5. MODEL STUDIO */}
            {activeTab === "Model" && (
              <motion.div
                key="model"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div>
                  <h2 className="text-2xl font-bold font-display text-white">ML Model Studio</h2>
                  <p className="text-sm text-slate-400">Configure parameters, select classification algorithms, and test vector vocabularies.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-start">
                  
                  {/* Left Column Config */}
                  <div className="lg:col-span-2 bg-slate-900 border border-slate-850 p-6 md:p-8 rounded-2xl space-y-5">
                    <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
                      <Sliders className="w-4 h-4 text-blue-400" /> Pipeline Configuration
                    </h3>

                    <div className="space-y-1.5">
                      <label className="text-xs font-semibold text-slate-400">Core Model Algorithm</label>
                      <select 
                        id="model-architecture-select"
                        value={modelType} 
                        onChange={(e) => setModelType(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 text-sm rounded-xl px-3.5 py-2.5 text-slate-300 outline-none focus:border-blue-500"
                      >
                        <option value="XGBoost Classifier">XGBoost Classifier (Preferred)</option>
                        <option value="Linear Logistic Regression">Linear Logistic Regression</option>
                      </select>
                    </div>

                    <div className="bg-slate-950/40 border border-slate-850/60 p-4 rounded-xl space-y-3 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 font-medium">Text cleaning regex parse</span>
                        <input 
                          id="clean-text-checkbox"
                          type="checkbox" 
                          checked={cleanTextCheck}
                          onChange={(e) => setCleanTextCheck(e.target.checked)}
                          className="w-4 h-4 rounded text-blue-500 focus:ring-blue-500 bg-slate-950 border-slate-800"
                        />
                      </div>

                      <div className="space-y-1 pt-1">
                        <div className="flex justify-between text-slate-400">
                          <span>Split validation size</span>
                          <span className="font-bold text-slate-300">{testSplit * 100}%</span>
                        </div>
                        <input 
                          id="test-split-slider"
                          type="range" 
                          min={0.10} 
                          max={0.40} 
                          step={0.05}
                          value={testSplit}
                          onChange={(e) => setTestSplit(parseFloat(e.target.value))}
                          className="w-full bg-slate-800 h-1 rounded-lg appearance-none cursor-pointer"
                        />
                      </div>

                      <div className="space-y-1 pt-1">
                        <div className="flex justify-between text-slate-400">
                          <span>Max vocabulary features</span>
                          <span className="font-bold text-slate-300">{maxFeatures}</span>
                        </div>
                        <input 
                          id="max-features-slider"
                          type="range" 
                          min={1000} 
                          max={10000} 
                          step={1000}
                          value={maxFeatures}
                          onChange={(e) => setMaxFeatures(parseInt(e.target.value))}
                          className="w-full bg-slate-800 h-1 rounded-lg appearance-none cursor-pointer"
                        />
                      </div>
                    </div>

                    <button
                      id="exec-train-btn"
                      onClick={handleModelTrain}
                      disabled={loading}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs py-3 px-4 rounded-xl shadow transition flex items-center justify-center gap-2"
                    >
                      {loading ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Training...</span>
                        </>
                      ) : (
                        <>
                          <Cpu className="w-4 h-4" />
                          <span>Run model training pipeline</span>
                        </>
                      )}
                    </button>

                    {loading && (
                      <p className="text-[11px] text-blue-500 text-center animate-pulse">{statusMessage}</p>
                    )}
                  </div>

                  {/* Right Column Metrics */}
                  <div className="lg:col-span-3 space-y-6">
                    {trainMetrics ? (
                      <div className="bg-slate-900 border border-slate-850 p-6 md:p-8 rounded-2xl space-y-6">
                        <div className="flex items-center gap-2 border-b border-slate-800 pb-4">
                          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                          <div>
                            <h3 className="text-base font-bold text-white">Pipeline Training Successfully Completed</h3>
                            <p className="text-xs text-slate-400">Binaries saved: model/model.pkl & model/vectorizer.pkl</p>
                          </div>
                        </div>

                        {/* Scores metrics */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
                          <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl text-center">
                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Accuracy</span>
                            <p className="text-xl font-bold font-display text-emerald-400 mt-1">{(trainMetrics.metrics.accuracy * 100).toFixed(2)}%</p>
                          </div>

                          <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl text-center">
                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Precision</span>
                            <p className="text-xl font-bold font-display text-slate-300 mt-1">{(trainMetrics.metrics.precision).toFixed(4)}</p>
                          </div>

                          <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl text-center">
                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Recall</span>
                            <p className="text-xl font-bold font-display text-slate-300 mt-1">{(trainMetrics.metrics.recall).toFixed(4)}</p>
                          </div>

                          <div className="bg-slate-950 p-4 border border-slate-850 rounded-xl text-center">
                            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">F1 Score</span>
                            <p className="text-xl font-bold font-display text-slate-300 mt-1">{(trainMetrics.metrics.f1Score).toFixed(4)}</p>
                          </div>
                        </div>

                        {/* 2D Confusion Matrix */}
                        <div className="space-y-3 pt-2">
                          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 font-mono">Stratified Confusion Matrix</h4>
                          <div className="grid grid-cols-3 gap-1 grid-flow-row border border-slate-800 rounded-xl overflow-hidden text-xs font-mono">
                            <div className="bg-slate-950 border-r border-b border-slate-800 p-3" />
                            <div className="bg-slate-950/80 border-r border-b border-slate-800 p-3 text-center font-bold text-slate-400">Actual REAL</div>
                            <div className="bg-slate-900 border-b border-slate-800 p-3 text-center font-bold text-slate-400">Actual FAKE</div>

                            <div className="bg-slate-950/80 border-r border-b border-slate-800 p-3 font-bold text-slate-400">Predicted REAL</div>
                            <div className="bg-emerald-500/10 border-r border-b border-slate-800 p-3 text-center">
                              <p className="font-bold text-emerald-400 font-display">{trainMetrics.metrics.confusionMatrix.tp}</p>
                              <span className="text-[10px] text-slate-500">True Neg (TN)</span>
                            </div>
                            <div className="bg-rose-500/5 border-b border-slate-800 p-3 text-center">
                              <p className="font-bold text-rose-450 font-display">{trainMetrics.metrics.confusionMatrix.fp}</p>
                              <span className="text-[10px] text-slate-500">False Pos (FP)</span>
                            </div>

                            <div className="bg-slate-900 border-r p-3 border-slate-800 font-bold text-slate-400">Predicted FAKE</div>
                            <div className="bg-rose-500/5 border-r p-3 border-slate-800 text-center">
                              <p className="font-bold text-rose-450 font-display">{trainMetrics.metrics.confusionMatrix.fn}</p>
                              <span className="text-[10px] text-slate-500">False Neg (FN)</span>
                            </div>
                            <div className="bg-rose-500/15 p-3 text-center">
                              <p className="font-bold text-rose-400 font-display">{trainMetrics.metrics.confusionMatrix.tn}</p>
                              <span className="text-[10px] text-slate-500">True Pos (TP)</span>
                            </div>
                          </div>
                        </div>

                      </div>
                    ) : (
                      <div className="h-full border border-dashed border-slate-850 rounded-2xl flex flex-col items-center justify-center text-center p-8 text-slate-500 min-h-[300px]">
                        <Cpu className="w-8 h-8 mb-4 text-slate-400" />
                        <div>
                          <p className="font-semibold text-slate-350">Awaiting Training trigger</p>
                          <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">Provide fitting configurations on the left panel to execute pipeline train.</p>
                        </div>
                      </div>
                    )}
                  </div>

                </div>
              </motion.div>
            )}

            {/* 6. HISTORY LOGS */}
            {activeTab === "History" && (
              <motion.div
                key="history"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="max-w-6xl mx-auto space-y-8"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold font-display text-white">Audit Verification Logs</h2>
                    <p className="text-sm text-slate-400">Search and manage records of previously executed classifications.</p>
                  </div>
                  
                  {history.length > 0 && (
                    <button
                      id="wipe-history-btn"
                      onClick={handleWipeHistory}
                      className="bg-slate-900 border border-rose-950 hover:bg-rose-500/10 text-rose-400 text-xs font-semibold py-2 px-4 rounded-xl flex items-center gap-2 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5 animate-pulse" /> Wipe history logs
                    </button>
                  )}
                </div>

                <div className="bg-slate-900 border border-slate-850 rounded-2xl p-6 md:p-8 space-y-5">
                  
                  {/* Search Bar */}
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      id="history-search"
                      type="text" 
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search snippets/titles or outcomes..."
                      className="w-full bg-slate-950 border border-slate-800 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm rounded-xl pl-11 pr-4 py-3 outline-none text-slate-200 transition"
                    />
                  </div>

                  {filteredHistory.length > 0 ? (
                    <div className="overflow-x-auto border border-slate-800 rounded-xl">
                      <table className="w-full border-collapse text-left text-xs bg-slate-950/40">
                        <thead>
                          <tr className="border-b border-slate-800 bg-slate-900/80 font-bold text-slate-400 font-mono">
                            <th className="px-4 py-3">Timestamp</th>
                            <th className="px-4 py-3">Headline / Snippet</th>
                            <th className="px-4 py-3 text-center">Prediction Outcome</th>
                            <th className="px-4 py-3 text-right">Confidence rating</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredHistory.map((item, i) => {
                            const d = new Date(item.timestamp);
                            const formattedDate = d.toLocaleDateString("en-US", { month: "short", day: "numeric" }) + " " + d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });
                            
                            return (
                              <tr key={i} className="border-b border-slate-850 hover:bg-slate-905 transition">
                                <td className="px-4 py-3.5 whitespace-nowrap text-slate-400 font-mono">{formattedDate}</td>
                                <td className="px-4 py-3.5 max-w-sm md:max-w-md">
                                  <p className="font-semibold text-slate-200 truncate">{item.title}</p>
                                  <p className="text-[11px] text-slate-400 truncate mt-0.5">{item.snippet}</p>
                                </td>
                                <td className="px-4 py-3.5 text-center whitespace-nowrap">
                                  <span className={`inline-block text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${item.prediction === "FAKE" ? "bg-rose-500/10 text-rose-500" : "bg-emerald-500/10 text-emerald-500"}`}>
                                    {item.prediction}
                                  </span>
                                </td>
                                <td className="px-4 py-3.5 text-right font-mono font-semibold text-slate-300">
                                  {Math.round(item.confidence * 100)}%
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="py-12 text-center text-slate-500 space-y-2">
                      <History className="w-8 h-8 mx-auto text-slate-400 mb-2" />
                      <p className="font-semibold text-slate-350">No historical entries found</p>
                      <p className="text-xs text-slate-500 max-w-xs mx-auto">No logs registered. Please direct some articles to the verification pipeline.</p>
                    </div>
                  )}

                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </main>
      </div>

      <footer id="app-footer" className="bg-slate-900 border-t border-slate-800 py-3 text-center text-[10px] text-slate-500 tracking-wider shrink-0 font-mono">
        &copy; {new Date().getFullYear()} Fake News Detector XAI. All rights reserved. Registered Portfolio Project.
      </footer>

    </div>
  );
}
